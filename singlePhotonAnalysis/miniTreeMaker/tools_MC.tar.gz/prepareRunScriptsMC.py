import re, random, os

#============================================================================
# Initial setting

numberOfJobs = 5 

fileName = "miniTreeMaker.C"
#nomDataSet = "QCD20"
#============================================================================
# Run the cmsDriver job
file = open("list","r")
dataSet = file.readlines()
file.close()

file = open(fileName, "r")
scriptLines = file.readlines()
file.close()

theCounter = 0
while theCounter < len(dataSet):
	theCounter += 1
	nomDataSet = dataSet[theCounter-1][:-1]
	print nomDataSet
	file = open("list_"+nomDataSet,"r")
	files = file.readlines()
	file.close()
	counter = 1
	fileNumber = 1
	while counter < len(files):
	    fileToCopy = "MiniTree_"+ str(fileNumber) + ".C"
	    fileNumber += 1

	    file = open(nomDataSet + "_miniTree/" + fileToCopy, "w")
	    for line in scriptLines:
	        if len(re.split("initialSeed ", line)) > 1:
	            file.write("        initialSeed = cms.untracked.uint32(" + str(int(random.random()*10000000)) + "),\n")
        	    continue
        
	        # process.source
        	if len(re.split("inputEventTree->Add", line)) > 1:
	            list = " "
		    list2 = " "
	            print "before the loop", counter, counter%numberOfJobs, len(files)
        	    if (numberOfJobs == 1):
                	list += "     inputEventTree->Add("
	                list += "\"" + files[counter-1][:-1] + "\");\n"
			list2 += "   inputRunTree->Add("
			list2 += "\"" + files[counter-1][:-1] + "\");\n" 
	                counter += 1
        	    while counter%numberOfJobs <> 0 and len(files) > counter:
                	print counter
	                if counter <> len(files) and counter%numberOfJobs <> 0:
			    list += "     inputEventTree->Add("
                	    list += "\"" + files[counter-1][:-1] + "\");\n"
			    list2 += "   inputRunTree->Add("
			    list2 += "\"" + files[counter-1][:-1] + "\");\n"	
                	    counter += 1
	                if (counter <> len(files) and counter%numberOfJobs == 0) or (counter == len(files)):
			    list += "     inputEventTree->Add("
                	    list += "\"" + files[counter-1][:-1] + "\");\n"
			    list2 += "   inputRunTree->Add("
			    list2 += "\"" + files[counter-1][:-1] + "\");\n"
                	    counter += 1
	                    break
        	    file.write(list)
		    file.write(list2)
        	    continue
	

	        # rename output file
        	if len(re.split("myFile=new", line)) > 1:
	            file.write(" myFile = new TFile(\"output_" + str(fileNumber-1) + ".root\",\"RECREATE\");\n")
        	    continue
	        file.write(line)
	    file.close()
