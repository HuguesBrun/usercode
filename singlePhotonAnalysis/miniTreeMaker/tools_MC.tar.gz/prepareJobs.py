import re, os

file = open("list","r")
dataSet = file.readlines()
file.close()

file = open("analyser.template","r")
scriptLines =  file.readlines()
file.close()

theCounter = 0
while theCounter < len(dataSet):
        theCounter += 1
        nomDataSet = dataSet[theCounter-1][:-1]
        print nomDataSet
	counter = 1
	dossierName = nomDataSet + "_miniTree"
	if (((len(os.listdir(dossierName))-3)/2)%3) <> 0 :
	    maxCounter = ((len(os.listdir(dossierName))-3)/6+2)
	else:
	    maxCounter = ((len(os.listdir(dossierName))-3)/6+1)
	while counter < maxCounter:
	    file = open(dossierName+"/tourneanalyser_"+str(counter)+".csh","w")
	    for line in scriptLines:
	        if len(re.split("myName",line)) > 1:
	             file.write("set theName=\""+nomDataSet+"\"\n")
	             continue
	        if len(re.split("coucou",line)) > 1:
	             file.write("set theName2=\""+nomDataSet+str(counter)+"\"\n")
	             continue
		if len(re.split("increment <",line)) > 1:
		    file.write("	if ($increment < "+str(((counter-1)*3)+1)+" ) then\n")
		    continue
		if len(re.split("increment >=",line)) > 1:
	 	    file.write("	if ($increment >= "+str(((counter)*3)+1)+" ) then\n")
		    continue
		file.write(line)
	    file.close()
	    counter += 1

