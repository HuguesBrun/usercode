import re, random, os

#============================================================================
# Initial setting


fileName = "template_miniTreeMaker.h"
#nomDataSet = "QCD20"
#============================================================================
# Run the cmsDriver job
file = open("listTrigger","r")
dataSet = file.readlines()
file.close()

file = open(fileName, "r")
scriptLines = file.readlines()
file.close()

theCounter = 0
while theCounter < len(dataSet):
	theCounter += 1
	nomDataSet = dataSet[theCounter-1][:-1]
	partiName = re.split(":",nomDataSet)[0]
	triggerName = re.split(":",nomDataSet)[1]
	print "partiName=", partiName, " triggerName=", triggerName
	file = open(partiName + "_miniTree/miniTreeMaker.h", "w")
	for line in scriptLines:
		if len(re.split("theTriggerStuff",line)) > 1:
			file2 = open(triggerName+".h","r")
			triggerLines = file2.readlines()
			file2.close()
			for lineTrigger in triggerLines:
				file.write(lineTrigger)
			continue
		file.write(line)
	file.close()